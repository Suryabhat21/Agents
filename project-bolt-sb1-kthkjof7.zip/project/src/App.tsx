import React, { useState } from 'react';
import { Upload, CheckCircle2, AlertCircle, Loader2, Brain, Code2, Cpu } from 'lucide-react';

type AgentStatus = {
  name: string;
  status: 'pending' | 'running' | 'completed' | 'error';
  message?: string;
  icon: React.ReactNode;
  description: string;
};

function App() {
  const [file, setFile] = useState<File | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [agents, setAgents] = useState<AgentStatus[]>([
    { 
      name: 'Junior Agent', 
      status: 'pending',
      icon: <Code2 className="w-8 h-8" />,
      description: 'Analyzes code structure and identifies basic patterns'
    },
    { 
      name: 'Senior Agent', 
      status: 'pending',
      icon: <Brain className="w-8 h-8" />,
      description: 'Evaluates architecture and suggests improvements'
    },
    { 
      name: 'Super Senior Agent', 
      status: 'pending',
      icon: <Cpu className="w-8 h-8" />,
      description: 'Performs deep analysis and generates comprehensive report'
    }
  ]);
  const [progress, setProgress] = useState(0);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const droppedFile = e.dataTransfer.files[0];
    if (droppedFile?.type === 'application/zip' || droppedFile?.type === 'application/x-zip-compressed') {
      setFile(droppedFile);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      setFile(selectedFile);
    }
  };

  const simulateAgentProgress = async () => {
    setIsProcessing(true);
    setProgress(0);
    
    // Simulate Junior Agent
    setAgents(prev => prev.map(agent => 
      agent.name === 'Junior Agent' ? { ...agent, status: 'running' } : agent
    ));
    
    for (let i = 0; i <= 33; i++) {
      setProgress(i);
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    
    setAgents(prev => prev.map(agent => 
      agent.name === 'Junior Agent' ? { ...agent, status: 'completed' } : agent
    ));

    // Simulate Senior Agent
    setAgents(prev => prev.map(agent => 
      agent.name === 'Senior Agent' ? { ...agent, status: 'running' } : agent
    ));
    
    for (let i = 34; i <= 66; i++) {
      setProgress(i);
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    
    setAgents(prev => prev.map(agent => 
      agent.name === 'Senior Agent' ? { ...agent, status: 'completed' } : agent
    ));

    // Simulate Super Senior Agent
    setAgents(prev => prev.map(agent => 
      agent.name === 'Super Senior Agent' ? { ...agent, status: 'running' } : agent
    ));
    
    for (let i = 67; i <= 100; i++) {
      setProgress(i);
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    
    setAgents(prev => prev.map(agent => 
      agent.name === 'Super Senior Agent' ? { ...agent, status: 'completed' } : agent
    ));

    setIsProcessing(false);
  };

  const handleSubmit = () => {
    if (file) {
      simulateAgentProgress();
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle2 className="w-6 h-6 text-green-500" />;
      case 'running':
        return <Loader2 className="w-6 h-6 text-blue-500 animate-spin" />;
      case 'error':
        return <AlertCircle className="w-6 h-6 text-red-500" />;
      default:
        return <div className="w-6 h-6 rounded-full border-2 border-gray-300" />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 p-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Code Analysis Tool</h1>
          <p className="text-lg text-gray-600">Upload your project ZIP file for comprehensive code analysis</p>
        </div>

        {!isProcessing ? (
          <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
            <div
              className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
                isDragging ? 'border-blue-500 bg-blue-50' : 'border-gray-300 hover:border-gray-400'
              }`}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
            >
              <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <div className="mb-4">
                <p className="text-lg text-gray-700 mb-2">
                  {file ? file.name : 'Drag and drop your ZIP file here'}
                </p>
                <p className="text-sm text-gray-500">or</p>
              </div>
              <label className="inline-flex items-center px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 cursor-pointer transition-colors">
                <span>Browse Files</span>
                <input
                  type="file"
                  className="hidden"
                  accept=".zip"
                  onChange={handleFileChange}
                />
              </label>
            </div>

            {file && (
              <div className="mt-6 text-center">
                <button
                  onClick={handleSubmit}
                  disabled={isProcessing}
                  className="px-6 py-3 bg-indigo-500 text-white rounded-lg font-medium hover:bg-indigo-600 transition-colors"
                >
                  Start Analysis
                </button>
              </div>
            )}
          </div>
        ) : (
          <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
            <div className="mb-8">
              <div className="flex justify-between mb-2">
                <span className="text-sm font-medium text-gray-700">Analysis Progress</span>
                <span className="text-sm font-medium text-gray-700">{progress}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2.5">
                <div 
                  className="bg-blue-500 h-2.5 rounded-full transition-all duration-300 ease-in-out"
                  style={{ width: `${progress}%` }}
                ></div>
              </div>
            </div>
            
            <div className="grid gap-6">
              {agents.map((agent, index) => (
                <div 
                  key={agent.name}
                  className={`p-6 rounded-lg transition-all duration-300 ${
                    agent.status === 'running' 
                      ? 'bg-blue-50 shadow-md scale-105' 
                      : agent.status === 'completed'
                      ? 'bg-green-50'
                      : 'bg-gray-50'
                  }`}
                >
                  <div className="flex items-start space-x-4">
                    <div className={`p-2 rounded-lg ${
                      agent.status === 'running' 
                        ? 'bg-blue-100' 
                        : agent.status === 'completed'
                        ? 'bg-green-100'
                        : 'bg-gray-100'
                    }`}>
                      {agent.icon}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <h3 className="text-lg font-medium text-gray-900">{agent.name}</h3>
                        {getStatusIcon(agent.status)}
                      </div>
                      <p className="text-sm text-gray-600 mt-1">{agent.description}</p>
                      {agent.status === 'running' && (
                        <div className="mt-3">
                          <p className="text-sm text-blue-600 animate-pulse">
                            Processing... Please wait
                          </p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;